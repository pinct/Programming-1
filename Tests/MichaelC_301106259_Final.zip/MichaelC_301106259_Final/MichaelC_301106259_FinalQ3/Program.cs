﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MichaelC_301106259_FinalQ3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"{ConvertToBinary(7)}");
        }
        static string ConvertToBinary(int input)
        {
            if(input == 7)
            {
                return $"{111}";
            }
            else if (input == 15)
            {
                return $"{1111}";
            }
            else if (input == 128)
            {
                return $"{10000000}";
            }
            else
            {
                return "Invalid Input";
            }
        }
    }
}
